from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Generic, TypeVar

from planframe.adapters.protocol import BackendAdapter
from planframe.core.plan import (
    DropPlan,
    FilterPlan,
    RenamePlan,
    SelectPlan,
    Source,
    WithColumnPlan,
)
from planframe.expr.core import Expr

PlanT = TypeVar("PlanT")
BackendT = TypeVar("BackendT")
BackendExprT = TypeVar("BackendExprT")
T = TypeVar("T")

@dataclass(frozen=True)
class Frame(Generic[PlanT, BackendT, BackendExprT]):
    _data: BackendT
    _adapter: BackendAdapter[BackendT, BackendExprT]
    _plan: PlanT

    @classmethod
    def from_source(
        cls,
        data: BackendT,
        adapter: BackendAdapter[BackendT, BackendExprT],
        schema: type[Any],
    ) -> "Frame[Source[Any], BackendT, BackendExprT]":
        return cls(_data=data, _adapter=adapter, _plan=Source(schema=schema))

    def select(self, *columns: str) -> "Frame[SelectPlan[PlanT], BackendT, BackendExprT]":
        new_data = self._adapter.select(self._data, tuple(columns))
        new_plan = SelectPlan(prev=self._plan, columns=tuple(columns))
        return Frame(_data=new_data, _adapter=self._adapter, _plan=new_plan)

    def drop(self, *columns: str) -> "Frame[DropPlan[PlanT], BackendT, BackendExprT]":
        new_data = self._adapter.drop(self._data, tuple(columns))
        new_plan = DropPlan(prev=self._plan, columns=tuple(columns))
        return Frame(_data=new_data, _adapter=self._adapter, _plan=new_plan)

    def rename(self, **mapping: str) -> "Frame[RenamePlan[PlanT], BackendT, BackendExprT]":
        new_data = self._adapter.rename(self._data, dict(mapping))
        new_plan = RenamePlan(prev=self._plan, mapping=dict(mapping))
        return Frame(_data=new_data, _adapter=self._adapter, _plan=new_plan)

    def with_column(self, name: str, expr: Expr[T]) -> "Frame[WithColumnPlan[PlanT], BackendT, BackendExprT]":
        compiled = self._adapter.compile_expr(expr)
        new_data = self._adapter.with_column(self._data, name, compiled)
        new_plan = WithColumnPlan(prev=self._plan, name=name, expr=expr)
        return Frame(_data=new_data, _adapter=self._adapter, _plan=new_plan)

    def filter(self, predicate: Expr[bool]) -> "Frame[FilterPlan[PlanT], BackendT, BackendExprT]":
        compiled = self._adapter.compile_expr(predicate)
        new_data = self._adapter.filter(self._data, compiled)
        new_plan = FilterPlan(prev=self._plan, predicate=predicate)
        return Frame(_data=new_data, _adapter=self._adapter, _plan=new_plan)

    def collect(self) -> BackendT:
        return self._adapter.collect(self._data)
