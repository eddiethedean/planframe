from dataclasses import dataclass
import polars as pl

from planframe import Frame, col, lit, add
from planframe.adapters.polars_adapter import PolarsAdapter

@dataclass
class UserSchema:
    id: int
    age: int

raw = pl.DataFrame({"id": [1, 2, 3], "age": [30, 40, 50]})
adapter = PolarsAdapter()

pf = Frame.from_source(raw.lazy(), adapter=adapter, schema=UserSchema)

result = (
    pf
    .select("id", "age")
    .with_column("age_plus_one", add(col("age"), lit(1)))
)

print(result.collect())
