# Roadmap

## MVP
- core Frame
- typed Expr[T]
- Polars adapter
- select/drop/rename/with_column/filter
- materialize_model design

## Next
- exact schema IR
- Pyright stub layer
- pandas adapter
- join semantics
- code generation
- plugin exploration
