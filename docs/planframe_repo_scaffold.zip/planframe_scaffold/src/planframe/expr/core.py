from __future__ import annotations
from dataclasses import dataclass
from typing import Generic, TypeVar, Any

T = TypeVar("T")

class Expr(Generic[T]):
    pass

@dataclass(frozen=True)
class Col(Expr[T]):
    name: str

@dataclass(frozen=True)
class Lit(Expr[T]):
    value: T

def col(name: str) -> Col[Any]:
    return Col(name=name)

def lit(value: T) -> Lit[T]:
    return Lit(value=value)
