from __future__ import annotations
from dataclasses import dataclass
from typing import Generic, TypeVar

from .core import Expr

T = TypeVar("T")

@dataclass(frozen=True)
class Add(Expr[int]):
    left: Expr[int]
    right: Expr[int]

@dataclass(frozen=True)
class Eq(Expr[bool], Generic[T]):
    left: Expr[T]
    right: Expr[T]

def add(left: Expr[int], right: Expr[int]) -> Add:
    return Add(left=left, right=right)

def eq_(left: Expr[T], right: Expr[T]) -> Eq[T]:
    return Eq(left=left, right=right)
