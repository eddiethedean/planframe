# PlanFrame — Minimal Working Repo Scaffold

This scaffold is a starting point for a pip-installable PlanFrame prototype.

It includes:
- a backend-agnostic core `Frame`
- a typed expression system
- a simple schema IR
- a runtime adapter protocol
- a minimal Polars adapter sketch
- an example file layout

This scaffold is intentionally conservative. It is designed to prove architecture, not to ship every advanced feature on day one.
