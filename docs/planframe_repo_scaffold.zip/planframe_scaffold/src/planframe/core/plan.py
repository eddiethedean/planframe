from __future__ import annotations
from dataclasses import dataclass
from typing import Generic, TypeVar, Any

SchemaT = TypeVar("SchemaT")
PrevPlanT = TypeVar("PrevPlanT")

@dataclass(frozen=True)
class Source(Generic[SchemaT]):
    schema: type[SchemaT]

@dataclass(frozen=True)
class SelectPlan(Generic[PrevPlanT]):
    prev: PrevPlanT
    columns: tuple[str, ...]

@dataclass(frozen=True)
class WithColumnPlan(Generic[PrevPlanT]):
    prev: PrevPlanT
    name: str
    expr: Any

@dataclass(frozen=True)
class RenamePlan(Generic[PrevPlanT]):
    prev: PrevPlanT
    mapping: dict[str, str]

@dataclass(frozen=True)
class DropPlan(Generic[PrevPlanT]):
    prev: PrevPlanT
    columns: tuple[str, ...]

@dataclass(frozen=True)
class FilterPlan(Generic[PrevPlanT]):
    prev: PrevPlanT
    predicate: Any
