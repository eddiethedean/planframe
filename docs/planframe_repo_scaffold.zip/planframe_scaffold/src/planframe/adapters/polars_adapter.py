from __future__ import annotations
from typing import Any

import polars as pl

from planframe.expr.core import Col, Lit, Expr
from planframe.expr.ops import Add, Eq

class PolarsAdapter:
    name = "polars"

    def select(self, df: pl.DataFrame | pl.LazyFrame, columns: tuple[str, ...]):
        return df.select(list(columns))

    def drop(self, df: pl.DataFrame | pl.LazyFrame, columns: tuple[str, ...]):
        return df.drop(list(columns))

    def rename(self, df: pl.DataFrame | pl.LazyFrame, mapping: dict[str, str]):
        return df.rename(mapping)

    def with_column(self, df: pl.DataFrame | pl.LazyFrame, name: str, expr: pl.Expr):
        return df.with_columns(expr.alias(name))

    def filter(self, df: pl.DataFrame | pl.LazyFrame, predicate: pl.Expr):
        return df.filter(predicate)

    def compile_expr(self, expr: Expr[Any]) -> pl.Expr:
        if isinstance(expr, Col):
            return pl.col(expr.name)
        if isinstance(expr, Lit):
            return pl.lit(expr.value)
        if isinstance(expr, Add):
            return self.compile_expr(expr.left) + self.compile_expr(expr.right)
        if isinstance(expr, Eq):
            return self.compile_expr(expr.left) == self.compile_expr(expr.right)
        raise TypeError(f"Unsupported expression node: {type(expr)!r}")

    def collect(self, df: pl.DataFrame | pl.LazyFrame):
        return df.collect() if isinstance(df, pl.LazyFrame) else df
